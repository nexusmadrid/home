# Liga Nexus — Landing Page

Hecha con **React + TypeScript + Vite**, `react-router-dom` para las rutas, `react-bootstrap` /
`bootstrap` para el layout, `react-icons` para iconos, `react-hook-form` para el formulario, y
**SASS/SCSS** para los estilos.

## Rutas

- `/` — Inicio (hero con propuesta de valor, beneficios, prueba social, CTAs)
- `/about` — Sobre nosotros (párrafo + foto, enlaces de vuelta a Inicio/Contacto)
- `/contact` — Únete ahora (formulario corto + canales de la comunidad)

## Mensaje central

Liga Nexus conecta a personas con talento dentro de la comunidad de 42 —talento técnico,
creativo y de negocio que hasta ahora no se había aprovechado— para llevar proyectos a la
realidad. No es una clase ni un club de charlas: es una comunidad de acción.

## Cómo cubre los requisitos de la landing

**Propuesta de valor clara** — el titular del hero ("Conectamos talento para llevar proyectos a
la realidad") y el subtítulo explican qué gana la persona (mentores, capital, visibilidad) y en
qué consiste la Liga, sin necesidad de hacer scroll.

**CTA visibles y orientados al beneficio** — "Únete ahora" y "Solicita tu plaza" aparecen en el
header, el hero y el cierre, todos apuntando a un formulario **corto** (`/contact`) con solo
cuatro campos esenciales: Nombre, Asunto, Email, Mensaje.

**Prueba social y credibilidad** — el Inicio incluye:
- Una tira de métricas (`siteConfig.metricas`), por ejemplo "50+ Proyectos impulsados".
- Tres testimonios (`TestimonialCard`).
- Una tira de logos de colaboradores/mentores (`SponsorLogos`), por ahora placeholders de texto,
  lista para sustituir por imágenes reales.

**Responsivo y rápido** — todo construido con el grid mobile-first de Bootstrap, sin JS pesado,
y `loading="lazy"` en imágenes bajo el pliegue. Para mantenerlo por debajo de ~3s en producción:
- Comprime o sustituye el fondo del hero (ver abajo) — mantenlo bajo ~300KB, idealmente en WebP.
- Sustituye las imágenes placeholder de testimonios/logos por archivos optimizados.
- Ejecuta `npm run build` y sirve la carpeta `dist/` desde un CDN o hosting estático.

## Estructura

```
src/
  layouts/MainLayout.tsx     Header + <Outlet> dentro de <main> + Footer
  components/
    Header.tsx
    Footer.tsx
    MemberCard.tsx
    TestimonialCard.tsx      Tarjeta de testimonio (prueba social)
    SponsorLogos.tsx         Tira de logos de colaboradores/mentores
    Stat.tsx                 Métrica destacada (ej. "50+ Proyectos impulsados")
  pages/
    Home.tsx
    About.tsx
    Contact.tsx
  siteConfig.ts               Enlaces, textos y métricas editables
  styles/
    _variables.scss
    _base.scss
    _hero.scss
    _components.scss
    main.scss
```

## Añadir tu logo

1. Copia tu archivo de logo a `src/assets/images/logo.png`.
2. En `src/components/Header.tsx`, borra el `<div>` placeholder y descomenta la línea `<img>`.

## Añadir el fondo del hero

1. Copia tus imágenes de escritorio/móvil a `src/assets/images/`.
2. En `src/styles/_hero.scss`, descomenta la línea `background-image` dentro de `.hero` (añade
   un media query si quieres usar la versión móvil por debajo de un breakpoint).

## Contenido editable (`src/siteConfig.ts`)

- `nombreComunidad`, `tagline`
- `whatsappUrl`, `slackUrl`, `githubUrl`, `linkedinUrl`
- `solicitudUrl`, `email`
- `metricas` — los números de la tira de prueba social en Inicio

## Desarrollo

```bash
npm install
npm run dev
```

## Build de producción

```bash
npm run build
npm run preview
```
