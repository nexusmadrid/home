interface SponsorLogosProps {
  names: string[]
}

// TODO: replace this text-based placeholder strip with real logo images
// (e.g. <img src="/src/assets/images/sponsors/acme.png" className="sponsor-logo" />)
export default function SponsorLogos({ names }: SponsorLogosProps) {
  return (
    <div className="d-flex flex-wrap justify-content-center align-items-center gap-4 gap-md-5">
      {names.map((name) => (
        <span key={name} className="sponsor-logo fw-bold fs-5 text-muted">
          {name}
        </span>
      ))}
    </div>
  )
}
