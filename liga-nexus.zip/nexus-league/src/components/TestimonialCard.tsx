import { Card } from 'react-bootstrap'
import { FaQuoteLeft } from 'react-icons/fa'

interface TestimonialCardProps {
  quote: string
  name: string
  role: string
  photo?: string
}

export default function TestimonialCard({ quote, name, role, photo }: TestimonialCardProps) {
  return (
    <Card className="testimonial-card h-100 p-4 shadow-sm">
      <Card.Body className="p-0 d-flex flex-column">
        <FaQuoteLeft className="text-primary mb-3" size={22} />
        <p className="testimonial-card__quote flex-grow-1">{quote}</p>
        <div className="d-flex align-items-center gap-3 mt-3">
          <img
            src={photo ?? 'https://placehold.co/80x80?text=Photo'}
            alt={name}
            width={48}
            height={48}
            className="rounded-circle"
            style={{ objectFit: 'cover' }}
          />
          <div>
            <div className="fw-semibold">{name}</div>
            <small className="text-muted">{role}</small>
          </div>
        </div>
      </Card.Body>
    </Card>
  )
}
