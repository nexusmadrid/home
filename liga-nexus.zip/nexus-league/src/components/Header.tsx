import { Navbar, Nav, Container, Button } from 'react-bootstrap'
import { NavLink, Link } from 'react-router-dom'
import { siteConfig } from '../siteConfig'

export default function Header() {
  return (
    <Navbar bg="dark" variant="dark" expand="md" sticky="top" className="py-3">
      <Container>
        <Navbar.Brand as={NavLink} to="/" className="d-flex align-items-center gap-2">
          {/*
            LOGO: coloca tu archivo de logo en /src/assets/images/logo.png
            y descomenta la línea de abajo (borra el div placeholder).
          */}
          {/* <img src="/src/assets/images/logo.png" alt={siteConfig.nombreComunidad} height={40} /> */}
          <div
            style={{
              width: 40,
              height: 40,
              borderRadius: '50%',
              background: 'var(--bs-primary)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: 700,
            }}
          >
            {siteConfig.nombreComunidad.charAt(0)}
          </div>
          <span className="fw-semibold">{siteConfig.nombreComunidad}</span>
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="main-navbar" />
        <Navbar.Collapse id="main-navbar">
          <Nav className="ms-auto align-items-md-center gap-md-2">
            <Nav.Link as={NavLink} to="/" end>
              Inicio
            </Nav.Link>
            <Nav.Link as={NavLink} to="/about">
              Quiénes somos
            </Nav.Link>
            <Nav.Link as={NavLink} to="/contact">
              Contacto
            </Nav.Link>
            <Button as={Link as any} to="/contact" variant="primary" className="ms-md-2 mt-2 mt-md-0">
              Únete ahora
            </Button>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  )
}
