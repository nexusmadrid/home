interface MemberCardProps {
  name: string
  role?: string
  photo?: string
}

export default function MemberCard({ name, role, photo }: MemberCardProps) {
  return (
    <div className="text-center">
      <img
        src={photo ?? 'https://placehold.co/300x300?text=Photo'}
        alt={name}
        className="member-photo mb-2"
      />
      <h6 className="mb-0 fw-semibold">{name}</h6>
      {role && <small className="text-muted">{role}</small>}
    </div>
  )
}
