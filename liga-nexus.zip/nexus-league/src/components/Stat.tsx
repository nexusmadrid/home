interface StatProps {
  value: string
  label: string
}

export default function Stat({ value, label }: StatProps) {
  return (
    <div className="stat text-center">
      <div className="stat__value">{value}</div>
      <div className="stat__label">{label}</div>
    </div>
  )
}
