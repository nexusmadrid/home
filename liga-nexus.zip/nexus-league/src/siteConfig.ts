// Configuración central del sitio.
// Cambia aquí los enlaces y textos que se repiten en toda la web.

export const siteConfig = {
  nombreComunidad: 'Liga Nexus',

  tagline: 'Conectamos talento de 42 para llevar proyectos a la realidad.',

  // Enlace provisional de WhatsApp (grupo o chat de invitación)
  whatsappUrl: 'https://chat.whatsapp.com/TU-ENLACE-AQUI',

  // A dónde va la solicitud para unirse
  solicitudUrl: 'mailto:tu-correo@dominio.com?subject=Solicitud%20para%20unirme%20a%20Liga%20Nexus',

  email: 'tu-correo@dominio.com',

  // Canales de la comunidad (edita con tus enlaces reales)
  slackUrl: 'https://join.slack.com/TU-ENLACE-AQUI',
  githubUrl: 'https://github.com/TU-ORGANIZACION',
  linkedinUrl: 'https://www.linkedin.com/company/TU-EMPRESA',

  // Métricas destacadas para la sección de prueba social — sustituye por datos reales
  metricas: [
    { valor: '50+', etiqueta: 'Proyectos impulsados' },
    { valor: '30+', etiqueta: 'Mentores activos' },
    { valor: '2M€+', etiqueta: 'Capital movilizado' },
    { valor: '500+', etiqueta: 'Personas en la red' },
  ],
}
