import { Container, Row, Col } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import { siteConfig } from '../siteConfig'

export default function About() {
  return (
    <>
      {/* SECCIÓN 1: PÁRRAFO GRANDE */}
      <section className="py-5">
        <Container>
          <Row className="justify-content-center">
            <Col lg={8}>
              <h1 className="fw-bold text-center mb-4">Sobre {siteConfig.nombreComunidad}</h1>
              <p className="fs-5 text-muted">
                {siteConfig.nombreComunidad} nace con un propósito claro: conectar a personas con
                talento dentro de la comunidad de 42 —talento técnico, creativo y de negocio que
                hasta ahora no se había aprovechado— para que puedan encontrarse, colaborar y
                llevar sus proyectos a la realidad. 42 reúne perfiles con alta capacidad técnica,
                autonomía y curiosidad, pero muchas ideas se quedan por el camino por falta de
                equipo, método o conexión con quien puede impulsarlas. Por eso no somos una clase
                ni un club pasivo de charlas: somos una comunidad de acción donde las personas
                pasan de la intención a la ejecución, aprenden construyendo, encuentran socios y
                convierten el potencial disperso del campus en proyectos reales.
              </p>
            </Col>
          </Row>
        </Container>
      </section>

      {/* SECCIÓN 2: FOTO */}
      <section className="py-5 bg-light">
        <Container>
          <Row className="justify-content-center">
            <Col lg={8} className="text-center">
              {/*
                FOTO: coloca tu imagen (foto de equipo, evento, etc.) en
                /src/assets/images/about.jpg y sustituye el src de abajo.
              */}
              <img
                src="https://placehold.co/900x500?text=Foto+de+la+comunidad"
                alt={`Comunidad de ${siteConfig.nombreComunidad}`}
                className="img-fluid rounded shadow-sm"
                loading="lazy"
              />
            </Col>
          </Row>
        </Container>
      </section>

      {/* ENLACES FINALES */}
      <section className="py-5">
        <Container className="text-center">
          <div className="d-flex justify-content-center gap-3 flex-wrap">
            <Link to="/" className="btn btn-outline-primary">
              Volver al inicio
            </Link>
            <Link to="/contact" className="btn btn-primary">
              Contáctanos
            </Link>
          </div>
        </Container>
      </section>
    </>
  )
}
