import { Container, Row, Col, Card } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import { FaUserTie, FaCoins, FaBullhorn } from 'react-icons/fa'
import TestimonialCard from '../components/TestimonialCard'
import SponsorLogos from '../components/SponsorLogos'
import Stat from '../components/Stat'
import { siteConfig } from '../siteConfig'

export default function Home() {
  return (
    <>
      {/* HERO — propuesta de valor clara + CTAs principales */}
      <section className="hero">
        <Container className="hero-content">
          <Row className="align-items-center">
            <Col lg={7}>
              <span className="badge bg-primary mb-3">Comunidad de emprendimiento · 42</span>
              <h1 className="display-4 fw-bold mb-3">
                Conectamos talento para llevar proyectos a la realidad.
              </h1>
              <p className="lead mb-4">
                {siteConfig.nombreComunidad} conecta a personas con talento dentro de la
                comunidad de 42 —talento que hasta ahora no se había aprovechado— con mentores,
                capital y visibilidad. Únete en minutos y forma parte de una comunidad pensada
                para construir, no solo para hablar de ideas.
              </p>
              <div className="d-flex gap-3 flex-wrap">
                <Link to="/contact" className="btn btn-primary btn-lg">
                  Únete ahora
                </Link>
                <Link to="/contact" className="btn btn-outline-light btn-lg">
                  Solicita tu plaza
                </Link>
              </div>
            </Col>
            {/* Lado derecho reservado intencionadamente para la imagen de fondo del hero */}
          </Row>
        </Container>
      </section>

      {/* QUÉ GANAS */}
      <section className="py-5">
        <Container>
          <h2 className="section-title text-center">Qué ganas</h2>
          <p className="text-center text-muted mb-5 mx-auto" style={{ maxWidth: 640 }}>
            Un camino estructurado para pasar de la idea a un proyecto real y con visibilidad.
          </p>
          <Row className="g-4">
            <Col md={4}>
              <Card className="h-100 text-center p-4 border-0 shadow-sm">
                <FaUserTie size={32} className="text-primary mx-auto mb-3" />
                <Card.Body className="p-0">
                  <Card.Title>Mentores</Card.Title>
                  <Card.Text className="text-muted">
                    Te ponemos en contacto con personas con experiencia real que te dan feedback
                    directo y honesto sobre tu idea y su ejecución.
                  </Card.Text>
                </Card.Body>
              </Card>
            </Col>
            <Col md={4}>
              <Card className="h-100 text-center p-4 border-0 shadow-sm">
                <FaCoins size={32} className="text-primary mx-auto mb-3" />
                <Card.Body className="p-0">
                  <Card.Title>Capital</Card.Title>
                  <Card.Text className="text-muted">
                    Acceso a una red de inversores y oportunidades de financiación a medida que tu
                    proyecto alcanza hitos clave.
                  </Card.Text>
                </Card.Body>
              </Card>
            </Col>
            <Col md={4}>
              <Card className="h-100 text-center p-4 border-0 shadow-sm">
                <FaBullhorn size={32} className="text-primary mx-auto mb-3" />
                <Card.Body className="p-0">
                  <Card.Title>Visibilidad</Card.Title>
                  <Card.Text className="text-muted">
                    Pitch Days, Founder Talks y espacios para dar a conocer tu proyecto a las
                    personas adecuadas.
                  </Card.Text>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Container>
      </section>

      {/* PRUEBA SOCIAL — métricas */}
      <section className="py-5 bg-light">
        <Container>
          <Row className="g-4">
            {siteConfig.metricas.map((m) => (
              <Col key={m.etiqueta} xs={6} md={3}>
                <Stat value={m.valor} label={m.etiqueta} />
              </Col>
            ))}
          </Row>
        </Container>
      </section>

      {/* PRUEBA SOCIAL — testimonios */}
      <section className="py-5">
        <Container>
          <h2 className="section-title text-center">Lo que dicen quienes ya construyeron aquí</h2>
          <p className="text-center text-muted mb-5 mx-auto" style={{ maxWidth: 640 }}>
            Resultados reales de personas que pasaron por la Liga.
          </p>
          <Row className="g-4">
            <Col md={4}>
              <TestimonialCard
                quote="En Liga Nexus encontré un mentor que me ayudó a arreglar mi pitch en una sola sesión. Dos meses después cerramos nuestra primera ronda."
                name="Alex Rivera"
                role="Fundador de Orbit Analytics"
              />
            </Col>
            <Col md={4}>
              <TestimonialCard
                quote="Me uní solo con una idea en una diapositiva. Las Build Sessions y la red de contactos me llevaron a un primer prototipo funcional en seis semanas."
                name="Sam Chen"
                role="Fundador de Loopwise"
              />
            </Col>
            <Col md={4}>
              <TestimonialCard
                quote="Solo la visibilidad del Pitch Day ya valió la pena unirme. Conseguimos tres presentaciones a inversores en la primera semana."
                name="Maria Gómez"
                role="Fundadora de Fielda"
              />
            </Col>
          </Row>
        </Container>
      </section>

      {/* PRUEBA SOCIAL — logos de sponsors/mentores */}
      <section className="py-5 bg-light">
        <Container>
          <p className="text-center text-muted mb-4 text-uppercase small fw-semibold">
            Con el respaldo de mentores y colaboradores de
          </p>
          <SponsorLogos
            names={['Acme Ventures', 'Red de Alumni 42', 'BuildCo', 'Northstar Capital', 'Founders Guild']}
          />
        </Container>
      </section>

      {/* CTA FINAL */}
      <section className="py-5">
        <Container className="text-center">
          <h2 className="section-title">¿Listo para construir algo real?</h2>
          <p className="text-muted mb-4 mx-auto" style={{ maxWidth: 560 }}>
            La solicitud lleva menos de 5 minutos. Sin formularios interminables ni esperas.
          </p>
          <div className="d-flex justify-content-center gap-3 flex-wrap">
            <Link to="/contact" className="btn btn-primary btn-lg">
              Únete ahora
            </Link>
            <Link to="/about" className="btn btn-outline-primary btn-lg">
              Conócenos mejor
            </Link>
          </div>
        </Container>
      </section>
    </>
  )
}
